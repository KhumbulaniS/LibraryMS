#include "Book.h"
#include <iostream>

Book::Book(int id, const std::string& title, const std::string& author, const std::string& genre)
    : LibraryItem(id, title, author), genre(genre) {}

void Book::displayInfo() const {
    std::cout << "[Book] ID: " << id << ", Title: " << title
              << ", Author: " << author << ", Genre: " << genre
              << ", Borrowed: " << (isBorrowed ? "Yes" : "No") << "\n";
}

std::string Book::serialize() const {
    return "BOOK|" + std::to_string(id) + "|" + title + "|" + author + "|" + genre + "|" + std::to_string(isBorrowed);
}
