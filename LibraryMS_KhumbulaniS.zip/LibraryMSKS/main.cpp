#include <iostream>
#include <fstream>
#include <memory>
#include <vector>
#include <sstream>
#include <limits>
#include "Book.h"
#include "Magazine.h"

using namespace std;

// Vector holds all library items
vector<shared_ptr<LibraryItem>> items;

// Save all items to file
void saveToFile(const string& filename)
{
    ofstream file(filename);
    for (const auto& item : items)
    {
        file << item->serialize() << endl;
    }
}

// Load all items from file to vector
void loadFromFile(const string& filename)
{
    items.clear();  // clear current data

    ifstream file(filename);
    string line;
    while (getline(file, line))
    {
        stringstream ss(line);
        string type;
        getline(ss, type, '|');  // Read type (BOOK or MAGAZINE)

        if (type == "BOOK")
        {
            int id; string title, author, genre; int borrowed;
            getline(ss, line, '|'); id = stoi(line);
            getline(ss, title, '|');
            getline(ss, author, '|');
            getline (ss, genre, '|' );
            getline(ss, line); borrowed = stoi(line);


            auto book = make_shared<Book>(id, title, author, genre);
            book->setIsBorrowed(borrowed);
            items.push_back(book);

        }
        else if (type == "MAGAZINE")
        {
            int id, issue, borrowed; string title, author;
            getline(ss, line, '|'); id = stoi(line);
            getline(ss, title, '|');
            getline(ss, author, '|');
            getline(ss, line, '|'); issue = stoi(line);
            getline(ss, line); borrowed = stoi(line);

            auto mag = make_shared<Magazine>(id, title, author, issue);
            mag->setIsBorrowed(borrowed);
            items.push_back(mag);
        }
    }
}

// Show manu
void showMenu()
{
    cout << "\n***************************************\n";
    cout << "         MILA'S LIBRARY SYSTEM         \n";
    cout << "_______________________________________\n";
    cout << "1. Add Book\n";
    cout << "2. Add Magazine\n";
    cout << "3. Display All\n";
    cout << "4. Borrow Item\n";
    cout << "5. Return Item\n";
    cout << "6. Search by Title\n";
    cout << "0. Exit\n";
    cout << "-------------------------------------\n";
    cout << "Choose: ";
}


// Reject values that are not numbers
int getValidInt(const string& prompt)
{
    int value;
    while (true)
    {
        cout << prompt;
        if (cin >> value)
        {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return value;
        }
        else
        {
            cout << "Invalid input, please enter a number.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }
}


// Add a new book
void addBook()
{
    int id = getValidInt("Book ID: ");
    string title, author, genre;

    cout << "Title: "; getline(cin, title);
    cout << "Author: "; getline(cin, author);
    cout << "Genre: "; getline(cin, genre);

    items.push_back(make_shared<Book>(id, title, author, genre));
    saveToFile("library_data.txt");
    cout << "The book has been added.\n";
}


// Add a new magazine
void addMagazine()
{
    int id = getValidInt("Magazine ID: ");
    string title, author;
    int issue = getValidInt("Issue Number: ");

    cout << "Title: "; getline(cin, title);
    cout << "Author: "; getline(cin, author);

    items.push_back(make_shared<Magazine>(id, title, author, issue));
    saveToFile("library_data.txt");
    cout << "The magazine has been added.\n";
}


// Borrow an item by ID if not already borrowed
void borrowItem()
{
    int id = getValidInt("Enter ID for item to borrow: ");

    for (auto& item : items)
    {
        if (item->getId() == id)
        {
            if (item->getIsBorrowed())
            {
                cout << "This item is already borrowed.\n";
                return;
            }

            item->setIsBorrowed(true);
            saveToFile("library_data.txt");
            cout << "Item borrowed successfully.\n";
            return;
        }
    }
    cout << "Item not found.\n";
}


// Return an item by ID if borrowed
void returnItem()
{
    int id = getValidInt("Enter ID to return: ");

    for (auto& item : items)
    {
        if (item->getId() == id)
        {
            if (!item->getIsBorrowed())
            {
                cout << "This item is not borrowed.\n";
                return;
            }
            item->setIsBorrowed(false);
            saveToFile("library_data.txt");
            cout << "Item returned successfully.\n";
            return;
        }
    }
    cout << "Item not found.\n";
}


// Search items by title substring (case-sensitive)
void searchItem()
{
    string title;
    cout << "Enter title to search: ";
    cin.ignore();
    getline(cin, title);

    bool found = false;
    for (const auto& item : items)
    {
        if (item->getTitle().find(title) != string::npos)
        {
            item->displayInfo();
            found = true;
        }
    }
    if (!found)
        cout << "No items matched your search.\n";
}






int main()
{
    loadFromFile("library_data.txt");  // Load existing data at startup

    int choice;
    do
    {
        showMenu();
        cin >> choice;
        cin.ignore();

        switch (choice)
        {
            case 1: addBook(); break;
            case 2: addMagazine(); break;
            case 3:
                loadFromFile("library_data.txt");  // Reload to display current file contents
                for (const auto& item : items)
                    item->displayInfo();
                break;
            case 4: borrowItem(); break;
            case 5: returnItem(); break;
            case 6: searchItem(); break;
            case 0: cout << "Goodbye!\n"; break;
            default: cout << "Invalid choice.\n";
        }
    } while (choice != 0);

    return 0;
}
