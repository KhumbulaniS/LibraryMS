#ifndef LIBRARYITEM_H
#define LIBRARYITEM_H

#include <string>

// Base class for Book and Magazine
class LibraryItem {
protected:
    int id;
    std::string title;
    std::string author;
    bool isBorrowed;

public:
    LibraryItem(int id, const std::string& title, const std::string& author);
    virtual ~LibraryItem() {}

    int getId() const;
    std::string getTitle() const;
    bool getIsBorrowed() const;
    void setIsBorrowed(bool b);

    virtual void displayInfo() const = 0;      // Show info
    virtual std::string serialize() const = 0; // Save item
};

#endif
