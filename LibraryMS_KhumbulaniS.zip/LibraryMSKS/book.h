#ifndef BOOK_H
#define BOOK_H

#include "LibraryItem.h"

// Book class from LibraryItem
class Book : public LibraryItem {
    std::string genre;  // Book genre

public:
    Book(int id, const std::string& title, const std::string& author, const std::string& genre);

    void displayInfo() const override;      // Show book info
    std::string serialize() const override; // Save book data
};

#endif
