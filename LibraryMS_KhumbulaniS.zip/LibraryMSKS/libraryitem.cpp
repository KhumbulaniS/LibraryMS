#include "LibraryItem.h"

LibraryItem::LibraryItem(int id, const std::string& title, const std::string& author)
    : id(id), title(title), author(author), isBorrowed(false) {}

int LibraryItem::getId() const {
    return id;
}

std::string LibraryItem::getTitle() const {
    return title;
}

bool LibraryItem::getIsBorrowed() const {
    return isBorrowed;
}

void LibraryItem::setIsBorrowed(bool b) {
    isBorrowed = b;
}
