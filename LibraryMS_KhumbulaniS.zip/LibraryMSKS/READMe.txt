Library System  
By: Khumbulani  Sikhosana
Student Number: 
11678488

---

About:
This is a small library system made in C++.  
It allows the user to add books and magazines, borrow and return them.  
You can also search items by title.  
The system saves the data in a text file so you don't lose it when the app closes.  

---

How to Use:
1. Open the project in Qt Creator or any C++ IDE that supports C++11 or later.
2. Build and run the program.
3. Follow the on-screen menu to:
   - Add a Book or Magazine
   - Borrow or Return an item
   - Search by Title
   - Display All items saved
4. Data is saved to "library_data.txt" in the same folder.

---

Files Included:
- main.cpp — Main program
- Book.h / Book.cpp — Book class
- Magazine.h / Magazine.cpp — Magazine class
- LibraryItem.h — Base class
- libraryItem.cpp

---

Note:
- The program checks that IDs are numbers.
- You can close and reopen the program — data will still be there.
