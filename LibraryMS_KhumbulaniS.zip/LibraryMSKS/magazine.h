#ifndef MAGAZINE_H
#define MAGAZINE_H

#include "LibraryItem.h"

// Magazine class that comes from LibraryItem
class Magazine : public LibraryItem {
    int issueNumber;

public:
    Magazine(int id, const std::string& title, const std::string& author, int issueNumber);

    void displayInfo() const override;        // Show info
    std::string serialize() const override;   // Save item
};

#endif
