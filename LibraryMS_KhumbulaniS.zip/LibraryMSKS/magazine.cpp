#include "Magazine.h"
#include <iostream>

Magazine::Magazine(int id, const std::string& title, const std::string& author, int issueNumber)
    : LibraryItem(id, title, author), issueNumber(issueNumber) {}

void Magazine::displayInfo() const {
    std::cout << "[Magazine] ID: " << id << ", Title: " << title
              << ", Author: " << author << ", Issue: " << issueNumber
              << ", Borrowed: " << (isBorrowed ? "Yes" : "No") << "\n";
}

std::string Magazine::serialize() const {
    return "MAGAZINE|" + std::to_string(id) + "|" + title + "|" + author + "|" + std::to_string(issueNumber) + "|" + std::to_string(isBorrowed);
}
